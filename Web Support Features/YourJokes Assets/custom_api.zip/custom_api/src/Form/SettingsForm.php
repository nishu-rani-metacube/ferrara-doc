<?php
namespace Drupal\custom_api\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\custom_api\php;

/**
 * Configure example settings for this site.
 */
class SettingsForm extends ConfigFormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'custom_api_admin_settings';
    }

    /**
     * {@inheritdoc}
     */
    protected function getEditableConfigNames() {
        return [
            'custom_api.settings',
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $config = new php\Config();

        $form['base_url'] = array(
            '#type' => 'textfield',
            '#title' => 'Base URL for Endpoint',
            '#description' => 'https://accounts.us1.gigya.com/',
            '#default_value' => $config->getBaseUrl(),
            '#required' => true
        );

        $form['api_key'] = array(
            '#type' => 'textfield',
            '#title' => 'API Key',
            '#description' => '',
            '#default_value' => $config->getApiKey(),
            '#required' => true
        );

        $form['user_key'] = array(
            '#type' => 'textfield',
            '#title' => 'User Key',
            '#description' => '',
            '#default_value' => $config->getUserKey(),
            '#required' => true
        );

        $form['secret'] = array(
            '#type' => 'textfield',
            '#title' => 'Secret',
            '#description' => '',
            '#default_value' => $config->getSecret(),
            '#required' => true
        );

        return parent::buildForm($form, $form_state);
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        
        $config = new php\Config();
        $config->setBaseUrl($form_state->getValue('base_url'));
        $config->setApiKey($form_state->getValue('api_key'));
        $config->setUserKey($form_state->getValue('user_key'));
        $config->setSecret($form_state->getValue('secret'));
        $config->save();

        parent::submitForm($form, $form_state);
    }

}