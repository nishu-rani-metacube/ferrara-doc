<?php

namespace Drupal\custom_api\Plugin\rest\resource;

use Drupal\taxonomy\Entity\Term;

class Joke{

    public string $joke;
    public string $answer;

    public function __construct(Term $term)
    {
        $this->joke = $term->field_joke[0]->value;
        $this->answer = $term->field_answer[0]->value;
    }
    
}