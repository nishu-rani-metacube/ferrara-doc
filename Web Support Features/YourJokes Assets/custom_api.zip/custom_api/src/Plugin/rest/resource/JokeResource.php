<?php

namespace Drupal\custom_api\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Drupal\custom_api\Plugin\rest\resource\JokeSubmission;
use Drupal\Core\Session\AccountProxyInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor;
use Symfony\Component\Serializer\Serializer;
use Drupal\rest\ModifiedResourceResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\PropertyInfo\PropertyInfoExtractor;
use Drupal\custom_api\php\Config;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Provides a Demo Resource
 *
 * @RestResource(
 *   id = "joke_resource",
 *   label = @Translation("Joke Resource"),
 *   uri_paths = {
 *     "canonical" = "/api/joke_resource",
 *     "create" = "/api/joke_resource"
 *   }
 * )
 */
class JokeResource extends ResourceBase
{
    // These values are handled in Drupal, but left for not Drupal implementations
    private $url = "https://accounts.us1.gigya.com/";
    private $api_key = "4_9h_IPcHxeLImQd7q20feAA";
    private $user_key = "AJaLi7HlRaJo";
    private $secret = "KATfcLAYOK6P2OMwDDbVpadraw0pCFCf";

    // private $config;
    // private string $url;
    // private string $api_key;
    // private string $user_key;
    // private $secret;

    private $init_path = "accounts.initRegistration";
    private $set_path = "accounts.setAccountInfo";

    /**
     * GET call to return a random joke
     */
    public function get(){
        $terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('jokes', 0, 1, false);

        $random = array_rand($terms, 1);
        $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($terms[$random]->tid);

        $joke = new Joke($term);
        $s = $this->get_serizalizer();

        $response = JsonResponse::fromJsonString($s->serialize($joke, "json"),);
        return $response;

    }

    /**
     * POST call to handle submission from front end
     */
    public function post(Request $request)
    {
        $s = $this->get_serizalizer();
        $joke = $s->deserialize($request->getContent(), JokeSubmission::class, 'json');
        $this->set_account($joke);

        $response = ['message' => 'Success'];
        return new ResourceResponse($response);
    }

    /**
     * Get an object for serializing/deserializing JSON data
     */
    private function get_serizalizer()
    {
        $encoders = [new JsonEncoder()];
        $extractor = new PropertyInfoExtractor([], [new ReflectionExtractor()]);
        $normalizers = [new ObjectNormalizer(null, null, null, $extractor)];
        return new Serializer($normalizers, $encoders);
    }

    /**
     * Submit record
     */
    private function set_account(JokeSubmission $joke)
    {
        $config = new Config();
        $serializer = $this->get_serizalizer();

        $params = [
            'apiKey' => $config->getApiKey(),
            'userKey' => $config->getUserKey(),
            'secret' => $config->getSecret(),
            'regToken' => $this->get_reg_token(),
            'profile' => $serializer->serialize($joke->profile, 'json'),
            'subscriptions' => $serializer->serialize(new JokeSubmissionSubscriptionWrapper(), "json"),
            'data' => $serializer->serialize($joke->data, "json")
        ];

        $ch = curl_init();
        $query_url = "{$config->getBaseUrl()}{$this->set_path}" . '?' . http_build_query($params);
        curl_setopt($ch, CURLOPT_URL, $query_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        $result = json_decode($response, true);

        if ($result["statusCode"] == 200) {
            return true;
        } else {
            throw new \Exception('Bad response');
        }
    }

    /**
     * Get reg token for other calls
     */
    private function get_reg_token()
    {
        $config = new Config();
        $params = [
            'isLite' => "true",
            'apiKey' => $config->getApiKey(),
            'userKey' => $config->getUserKey(),
            'secret' => $config->getSecret()
        ];

        $ch = curl_init();
        $query_url = "{$config->getBaseUrl()}{$this->init_path}" . '?' . http_build_query($params);
        curl_setopt($ch, CURLOPT_URL, $query_url);
        // curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        curl_close($ch);

        $result = json_decode($response, true);

        if ($result['statusCode'] == 200) {
            return $result['regToken'];
        } else {
            throw new \Exception('Bad response');
        }
    }
}
