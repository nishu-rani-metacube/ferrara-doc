<?php

namespace Drupal\custom_api\Plugin\rest\resource;


class JokeSubmission
{
    public Profile $profile;
    public Joke $data;
}

class Profile
{
    public string $firstName;
    public string $lastName;
    public string $gender;
    public string $email;
    public string $address;
    public string $city;
    public string $state;
    public string $zip;
    public JokeSubmissionPhone $phones;
}

class Joke
{
    public string $joke;
    public string $answer;
}

class JokeSubmissionPhone
{
    public string $number;
}

class JokeSubmissionSubscriptionWrapper
{
    public JokeSubmissionSubscription $Laffy_Taffy_site;
    public function __construct(bool $is_subscribed = true)
    {
        $this->Laffy_Taffy_site = new JokeSubmissionSubscription($is_subscribed);
    }
}

class JokeSubmissionSubscription
{
    public JokeSubmissionSubscriptionEmail $email;

    public function __construct(bool $is_subscribed = true)
    {
        $this->email = new JokeSubmissionSubscriptionEmail($is_subscribed);
    }
}

class JokeSubmissionSubscriptionEmail
{
    public bool $isSubscribed;

    public function __construct(bool $is_subscribed = true)
    {
        $this->isSubscribed = $is_subscribed;
    }
}
