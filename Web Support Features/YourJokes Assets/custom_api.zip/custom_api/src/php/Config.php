<?php

namespace Drupal\custom_api\php;

class Config
{

    private $keys = [
        'custom_api.base_url',
        'custom_api.api_key',
        'custom_api.user_key',
        'custom_api.secret',
    ];
    private $pairs;

    public function __construct()
    {
        $this->pairs = \Drupal::state()->getMultiple($this->keys);
    }

    public function getBaseUrl()
    {
        return $this->pairs['custom_api.base_url'];
    }

    public function setBaseUrl($value)
    {
        $this->pairs['custom_api.base_url'] = $value;
    }

    public function getApiKey()
    {
        return $this->pairs['custom_api.api_key'];
    }

    public function setApiKey($value)
    {
        $this->pairs['custom_api.api_key'] = $value;
    }

    public function getUserKey()
    {
        return $this->pairs['custom_api.user_key'];
    }

    public function setUserKey($value)
    {
        $this->pairs['custom_api.user_key'] = $value;
    }

    public function getSecret()
    {
        return $this->pairs['custom_api.secret'];
    }

    public function setSecret($value)
    {
        $this->pairs['custom_api.secret'] = $value;
    }

    public function save()
    {
        $keyvalues = [
            'custom_api.base_url' =>             $this->pairs['custom_api.base_url'],
            'custom_api.api_key' =>            $this->pairs['custom_api.api_key'],
            'custom_api.user_key' =>     $this->pairs['custom_api.user_key'],
            'custom_api.secret' =>    $this->pairs['custom_api.secret'],
        ];

        \Drupal::state()->setMultiple($keyvalues);
    }
}
